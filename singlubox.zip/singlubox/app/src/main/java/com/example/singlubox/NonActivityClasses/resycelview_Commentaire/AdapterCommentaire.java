package com.example.singlubox.NonActivityClasses.resycelview_Commentaire;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.singlubox.R;

import java.util.List;

public class AdapterCommentaire extends RecyclerView.Adapter<HolderCommentaire> {
    private Context context;
    private List<ItemCommentaire> commantaires;

    public AdapterCommentaire(Context context, List<ItemCommentaire> commantaires) {
        this.context = context;
        this.commantaires = commantaires;
    }

    @NonNull
    @Override
    public HolderCommentaire onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new HolderCommentaire(LayoutInflater.from(context).inflate(R.layout.layout_commantaire,parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull HolderCommentaire holder, int position) {
        ItemCommentaire commantaire = commantaires.get(position);

        holder.user.setText(commantaire.getUser());
        holder.contenu.setText(commantaire.getContenu());

    }


    @Override
    public int getItemCount() {
        return commantaires.size();
    }
}
