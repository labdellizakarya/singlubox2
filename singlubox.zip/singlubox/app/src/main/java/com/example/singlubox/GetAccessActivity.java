package com.example.singlubox;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.singlubox.NonActivityClasses.DataBase;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

public class GetAccessActivity extends AppCompatActivity {

    EditText accee;
    ImageButton accept;
    SwitchCompat rememberMe;
    ProgressBar progressBar;
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.getaccessctivity);

        if (DataBase.getInstance(GetAccessActivity.this).MedcinExist()) {
            DataBase.getInstance(getApplicationContext()).getMedcinRefFromDataBase();
            finish();
            startActivity(new Intent(GetAccessActivity.this, MainActivity.class));
        }

        try {
        } catch (Exception e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();
        }


        accee = findViewById(R.id.get_access_code);
        accept = findViewById(R.id.get_access_accept);
        rememberMe = findViewById(R.id.get_access_remember_me);
        progressBar = findViewById(R.id.get_access_progress_bar);

        accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                verifyCodeAccee(accee.getText().toString(),rememberMe.isActivated());
            }


        });
    }
    private void verifyCodeAccee(String code, boolean activated) {
        FirebaseFirestore.getInstance()
                .collection("Medcin")
                .whereEqualTo("code_acee",code)
                .get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        if (queryDocumentSnapshots.getDocuments().isEmpty()){
                            Toast.makeText(GetAccessActivity.this, "code erreur", Toast.LENGTH_SHORT).show();
                        }else{
                            DataBase.getInstance(GetAccessActivity.this).setMedcinRef(
                                    activated,
                                    queryDocumentSnapshots.getDocuments().get(0).getReference());
                            finish();
                            startActivity(new Intent(GetAccessActivity.this,MainActivity.class));
                        }
                    }
                });
    }

}
