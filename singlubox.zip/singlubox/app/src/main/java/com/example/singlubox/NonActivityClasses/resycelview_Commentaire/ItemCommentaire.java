package com.example.singlubox.NonActivityClasses.resycelview_Commentaire;

public class ItemCommentaire {
    String user,contenu;

    public ItemCommentaire(String user, String contenu) {
        this.user = user;
        this.contenu = contenu;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getContenu() {
        return contenu;
    }

    public void setContenu(String contenu) {
        this.contenu = contenu;
    }
}
