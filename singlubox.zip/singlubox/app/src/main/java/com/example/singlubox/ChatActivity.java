package com.example.singlubox;

import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ChatActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private EditText messageInput;
    private Button sendButton;
    private String currentUserId;
    private String receiverId;
    private DatabaseReference messagesRef;
    private ValueEventListener messagesListener;
    private List<Message> messageList;
    private MessageAdapter messageAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);

        currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        receiverId = getIntent().getStringExtra("receiverId");
        messagesRef = FirebaseDatabase.getInstance().getReference().child("messages")
                .child(currentUserId).child(receiverId);

        recyclerView = findViewById(R.id.recycler_view);
        messageInput = findViewById(R.id.message_input);
        sendButton = findViewById(R.id.send_button);

        messageList = new ArrayList<>();
        messageAdapter = new MessageAdapter(messageList, currentUserId, messagesRef);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(messageAdapter);

        messagesListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                messageList.clear();
                for (DataSnapshot messageSnapshot : dataSnapshot.getChildren()) {
                    Message message = messageSnapshot.getValue(Message.class);
                    messageList.add(message);
                }
                messageAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.d("ChatActivity", "onCancelled: " + databaseError.getMessage());
            }
        };
        messagesRef.addValueEventListener(messagesListener);

        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = messageInput.getText().toString();
                if (!TextUtils.isEmpty(text)) {
                    messageAdapter.addMessage(text, receiverId);
                    messageInput.setText("");
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        messageAdapter.removeListener();
        messagesRef.removeEventListener(messagesListener);
    }
}
/*
        import androidx.appcompat.app.AppCompatActivity;
        import androidx.recyclerview.widget.LinearLayoutManager;
        import androidx.recyclerview.widget.RecyclerView;

        import android.os.Bundle;

        import java.util.ArrayList;
        import java.util.Date;
        import java.util.List;

public class ChatActivity extends AppCompatActivity {
    private RecyclerView messageRecyclerView;
    private MessageAdapter messageAdapter;
    private List<Message> messageList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        // Initialize RecyclerView
        messageRecyclerView = findViewById(R.id.message_recycler_view);
        messageRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize MessageAdapter and set it to RecyclerView
        messageAdapter = new MessageAdapter();
        messageRecyclerView.setAdapter(messageAdapter);

        // Initialize messageList with some dummy data
        messageList = new ArrayList<>();
        messageList.add(new Message("Hello", true, new Date()));
        messageList.add(new Message("Hi there!", false, new Date()));
        messageList.add(new Message("How are you?", true, new Date()));

        // Set messageList to MessageAdapter
        messageAdapter.setMessageList(messageList);
    }
}/*

