package com.example.singlubox;

//import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
//import android.provider.ContactsContract;
//import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.singlubox.NonActivityClasses.DataBase;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;

public class MainActivity extends AppCompatActivity {

    Button Messagrie,Publication,profile;
    TextView bonjour;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        bonjour = findViewById(R.id.main_bonjour);
        Publication = findViewById(R.id.main_Publication);
        Messagrie = findViewById(R.id.main_Messagrie);
        profile = findViewById(R.id.main_profile);

       



        setUpBonjour();

        Publication.setOnClickListener(view -> startActivity(new Intent(MainActivity.this,PublicationActivity.class)));

        Messagrie.setOnClickListener(view -> startActivity(new Intent(MainActivity.this,MessagrieActivity.class)));

        profile.setOnClickListener(view -> startActivity(new Intent(MainActivity.this, activity_profile.class)));
    }


    void setUpBonjour (){
        DataBase.getInstance(MainActivity.this).getMedcinRef()
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (!documentSnapshot.contains("nom"))
                        bonjour.setText("Veuller modifier votre informations dans Profile!");
                    else
                        bonjour.setText("Bonjour " + documentSnapshot.getString("nom") + "!");
                })
                .addOnFailureListener(e -> Toast.makeText(MainActivity.this, e.toString(), Toast.LENGTH_SHORT).show());
    }
}