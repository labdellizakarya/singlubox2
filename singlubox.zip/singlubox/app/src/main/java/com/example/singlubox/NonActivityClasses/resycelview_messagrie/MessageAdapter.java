package com.example.singlubox.NonActivityClasses.resycelview_messagrie;

public class MessageAdapter {
}
