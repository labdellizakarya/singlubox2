package com.example.singlubox.NonActivityClasses.resycelview_Commentaire;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.singlubox.R;

public class HolderCommentaire extends RecyclerView.ViewHolder {

    TextView user,contenu;

    public HolderCommentaire (@NonNull View itemView) {
        super(itemView);

        user = itemView.findViewById(R.id.commantaire_user);
        contenu = itemView.findViewById(R.id.commantaire_contenu);
    }
}
