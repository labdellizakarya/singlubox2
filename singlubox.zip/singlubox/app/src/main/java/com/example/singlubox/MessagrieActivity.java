package com.example.singlubox;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MessagrieActivity extends AppCompatActivity {

    private RecyclerView mMessageRecyclerView;
    private EditText mMessageEditText;
    private Button mSendButton;

    private List<Message> mMessageList = new ArrayList<>();
    private MessageAdapter mAdapter;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mMessageRecyclerView = findViewById(R.id.recycler_view);
        mMessageEditText = findViewById(R.id.message_edit_text);
        mSendButton = findViewById(R.id.send_button);

        mAdapter = new MessageAdapter(mMessageList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        mMessageRecyclerView.setLayoutManager(layoutManager);
        mMessageRecyclerView.setAdapter(mAdapter);

        mSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String messageText = mMessageEditText.getText().toString();
                if (!messageText.isEmpty()) {
                    Message message = new Message(messageText, true);
                    mMessageList.add(message);
                    mAdapter.notifyItemInserted(mMessageList.size() - 1);
                    mMessageRecyclerView.scrollToPosition(mMessageList.size() - 1);
                    mMessageEditText.setText("");
                }
            }
        });
    }
}
